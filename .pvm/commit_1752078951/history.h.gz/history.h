#ifndef PVM_HISTORY_H
#define PVM_HISTORY_H

int pvm_history(int argc, char *argv[]);

#endif // PVM_HISTORY_H
