#ifndef PVM_SAVE_H
#define PVM_SAVE_H

int pvm_save(int argc, char *argv[]);
int pvm_index_git(void);

#endif // PVM_SAVE_H
