#ifndef PVM_INIT_H
#define PVM_INIT_H

int pvm_init();

#endif // PVM_INIT_H
