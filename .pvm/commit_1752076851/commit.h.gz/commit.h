#ifndef PVM_COMMIT_H
#define PVM_COMMIT_H

int pvm_commit(int argc, char *argv[]);

#endif // PVM_COMMIT_H
