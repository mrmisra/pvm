#ifndef PVM_SAVE_H
#define PVM_SAVE_H

int pvm_save(int argc, char *argv[]);

#endif // PVM_SAVE_H
